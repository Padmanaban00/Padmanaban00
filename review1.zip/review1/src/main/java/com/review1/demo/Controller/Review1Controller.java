package com.review1.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.review1.demo.Service.Review1Service;
import com.review1.demo.model.Review1Model;

@RestController
public class Review1Controller {
	@Autowired
	Review1Service a;
	@GetMapping(value="/getid")
	public List<Review1Model> getAllReview1Model()
	{
		List<Review1Model> RevList=a.getAllReview1Models();
		return RevList;
	}
	@PostMapping(value="/saveid")
	public Review1Model saveReview1Model(@RequestBody Review1Model b) 
	{
		return a.saveReview1Model(b);
	}
	@PutMapping(value="/updatevalue")
	public Review1Model updateReview1Model(@RequestBody Review1Model b)
	{
		return a.saveReview1Model(b);
	}
	@DeleteMapping("/deleid/{id}")
	public String deleteReview1Model(@PathVariable("id") int id)
	{
		 return a.deleteReview1Model(id);
	}
	@GetMapping(value="/getid1/{id}")
	public Review1Model getReview1Model(@PathVariable("id") int id)
	{
		return a.getReview1Model(id);
	}
}
