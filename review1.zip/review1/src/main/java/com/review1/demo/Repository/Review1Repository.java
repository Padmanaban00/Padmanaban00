package com.review1.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.review1.demo.model.Review1Model;

public interface Review1Repository extends JpaRepository<Review1Model,Integer> {

}
