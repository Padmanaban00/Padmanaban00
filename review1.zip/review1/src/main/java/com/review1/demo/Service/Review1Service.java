package com.review1.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.review1.demo.Repository.*;
import com.review1.demo.model.Review1Model;

@Service
public class Review1Service {
	@Autowired
	Review1Repository r;
	public List<Review1Model> getAllReview1Models()
	{
		List<Review1Model> revList=r.findAll();
		return revList;
	}
	public Review1Model saveReview1Model (Review1Model s)
	{
		
		return r.save(s);
		
	}
	public String deleteReview1Model(int id)
	{
		r.deleteById(id);
		return "Id has been deleted";
	}
	public Review1Model getReview1Model(int id)
	{
		return r.findById(id).get();
	}

}
